package br.com.cesarschool.poo.utils;

public abstract class Identificavel {

    public abstract String getIdentificadorUnico();
}
