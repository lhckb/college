package br.com.cesarschool.poo.utils;

public interface Comparavel {

    public int comparar(Object objeto);
}
