package br.com.cesarschool.poo.utils;

public interface Comparador {
    public int comparar(Object o1, Object o2);
}
