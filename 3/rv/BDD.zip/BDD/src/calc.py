class Calculadora:
    def somar(self, op1, op2):
        return op1 + op2

    def subtrair(self, op1, op2):
        return op1 - op2

    def dividir(self, op1, op2):
        return op1 / op2

    def multiplicar(self, op1, op2):
        return op1 * op2

    def potencia(self, op1, op2):
        return op1 ** op2
        